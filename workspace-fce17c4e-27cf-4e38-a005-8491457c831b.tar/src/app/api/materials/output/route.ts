import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// WebSocket server instance
let io: any = null;

// Initialize WebSocket server
if (typeof globalThis.io === 'undefined') {
  const { Server } = require('socket.io');
  const { createServer } = require('http');
  const { parse } = require('url');
  
  // Get the Next.js server instance
  const nextServer = globalThis.nextServer;
  if (nextServer) {
    io = new Server(nextServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    // Setup socket handlers
    io.on('connection', (socket: any) => {
      console.log('Client connected to material updates:', socket.id);
    });
    
    globalThis.io = io;
  }
}

export async function GET() {
  try {
    const outputs = await db.materialOutput.findMany({
      include: {
        material: true
      },
      orderBy: {
        date: 'desc'
      }
    })

    return NextResponse.json(outputs)
  } catch (error) {
    console.error('Error fetching material outputs:', error)
    return NextResponse.json({ error: 'Failed to fetch material outputs' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { date, time, materialName, quantity, unit, destination, recipient, notes } = await request.json()

    if (!date || !time || !materialName || !quantity || !unit || !destination || !recipient) {
      return NextResponse.json({ error: 'Date, time, material name, quantity, unit, destination, and recipient are required' }, { status: 400 })
    }

    // Check if material exists and has enough stock
    const material = await db.material.findUnique({
      where: { name: materialName }
    })

    if (!material) {
      return NextResponse.json({ error: 'Material not found' }, { status: 404 })
    }

    if (material.stock < quantity) {
      return NextResponse.json({ error: 'Insufficient stock' }, { status: 400 })
    }

    // Update material stock
    const updatedMaterial = await db.material.update({
      where: { id: material.id },
      data: {
        totalOut: {
          increment: quantity
        },
        stock: {
          decrement: quantity
        }
      }
    })

    // Create output record
    const output = await db.materialOutput.create({
      data: {
        date: new Date(date),
        time,
        quantity,
        unit,
        destination,
        recipient: recipient || null,
        notes: notes || null,
        materialId: material.id
      },
      include: {
        material: true
      }
    })

    // Emit real-time update to all connected clients
    if (io) {
      const updateData = {
        type: 'material-output',
        data: {
          output: {
            id: output.id,
            date: output.date,
            time: output.time,
            quantity: output.quantity,
            unit: output.unit,
            destination: output.destination,
            recipient: output.recipient,
            notes: output.notes,
            material: output.material
          },
          material: {
            id: updatedMaterial.id,
            name: updatedMaterial.name,
            partNumber: updatedMaterial.partNumber,
            unit: updatedMaterial.unit,
            totalIn: updatedMaterial.totalIn,
            totalOut: updatedMaterial.totalOut,
            stock: updatedMaterial.stock
          }
        },
        timestamp: new Date().toISOString()
      }
      
      io.emit('material-update', updateData)
      console.log('Broadcasting material output update:', updateData)
    }

    return NextResponse.json({ output, material: updatedMaterial }, { status: 201 })
  } catch (error) {
    console.error('Error creating material output:', error)
    return NextResponse.json({ error: 'Failed to create material output' }, { status: 500 })
  }
}
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get('search') || ''

    const materials = await db.material.findMany({
      where: {
        name: {
          contains: search
        }
      },
      include: {
        inputs: {
          orderBy: {
            date: 'desc'
          }
        },
        outputs: {
          orderBy: {
            date: 'desc'
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    // Calculate totals
    const totalMaterials = materials.length
    const totalStock = materials.reduce((sum, material) => sum + material.stock, 0)
    const totalInput = materials.reduce((sum, material) => sum + material.totalIn, 0)
    const totalOutput = materials.reduce((sum, material) => sum + material.totalOut, 0)

    const report = {
      materials,
      summary: {
        totalMaterials,
        totalStock,
        totalInput,
        totalOutput
      }
    }

    return NextResponse.json(report)
  } catch (error) {
    console.error('Error generating material report:', error)
    return NextResponse.json({ error: 'Failed to generate material report' }, { status: 500 })
  }
}
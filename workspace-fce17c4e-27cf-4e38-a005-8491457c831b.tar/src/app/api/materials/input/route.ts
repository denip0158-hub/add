import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// WebSocket server instance
let io: any = null;

// Initialize WebSocket server
if (typeof globalThis.io === 'undefined') {
  const { Server } = require('socket.io');
  const { createServer } = require('http');
  const { parse } = require('url');
  
  // Get the Next.js server instance
  const nextServer = globalThis.nextServer;
  if (nextServer) {
    io = new Server(nextServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"]
      }
    });
    
    // Setup socket handlers
    io.on('connection', (socket: any) => {
      console.log('Client connected to material updates:', socket.id);
    });
    
    globalThis.io = io;
  }
}

export async function GET() {
  try {
    const inputs = await db.materialInput.findMany({
      include: {
        material: true
      },
      orderBy: {
        date: 'desc'
      }
    })

    return NextResponse.json(inputs)
  } catch (error) {
    console.error('Error fetching material inputs:', error)
    return NextResponse.json({ error: 'Failed to fetch material inputs' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { date, time, materialName, partNumber, quantity, unit, supplier, notes } = await request.json()

    if (!date || !time || !materialName || !quantity || !unit) {
      return NextResponse.json({ error: 'Date, time, material name, quantity, and unit are required' }, { status: 400 })
    }

    // Check if material exists, if not create it
    let material = await db.material.findUnique({
      where: { name: materialName }
    })

    if (!material) {
      material = await db.material.create({
        data: {
          name: materialName,
          partNumber: partNumber || null,
          unit,
          totalIn: quantity,
          stock: quantity
        }
      })
    } else {
      // Update material stock and part number if provided
      material = await db.material.update({
        where: { id: material.id },
        data: {
          totalIn: {
            increment: quantity
          },
          stock: {
            increment: quantity
          },
          ...(partNumber && { partNumber })
        }
      })
    }

    // Create input record
    const input = await db.materialInput.create({
      data: {
        date: new Date(date),
        time,
        quantity,
        supplier: supplier || null,
        notes: notes || null,
        materialId: material.id
      },
      include: {
        material: true
      }
    })

    // Emit real-time update to all connected clients
    if (io) {
      const updateData = {
        type: 'material-input',
        data: {
          input: {
            id: input.id,
            date: input.date,
            time: input.time,
            quantity: input.quantity,
            supplier: input.supplier,
            notes: input.notes,
            material: input.material
          },
          material: {
            id: material.id,
            name: material.name,
            partNumber: material.partNumber,
            unit: material.unit,
            totalIn: material.totalIn,
            totalOut: material.totalOut,
            stock: material.stock
          }
        },
        timestamp: new Date().toISOString()
      }
      
      io.emit('material-update', updateData)
      console.log('Broadcasting material input update:', updateData)
    }

    return NextResponse.json({ input, material }, { status: 201 })
  } catch (error) {
    console.error('Error creating material input:', error)
    return NextResponse.json({ error: 'Failed to create material input' }, { status: 500 })
  }
}
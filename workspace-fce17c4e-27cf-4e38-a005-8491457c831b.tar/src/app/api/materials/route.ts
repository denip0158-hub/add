import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const materials = await db.material.findMany({
      include: {
        inputs: true,
        outputs: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(materials)
  } catch (error) {
    console.error('Error fetching materials:', error)
    return NextResponse.json({ error: 'Failed to fetch materials' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, unit } = await request.json()

    if (!name || !unit) {
      return NextResponse.json({ error: 'Name and unit are required' }, { status: 400 })
    }

    const existingMaterial = await db.material.findUnique({
      where: { name }
    })

    if (existingMaterial) {
      return NextResponse.json({ error: 'Material already exists' }, { status: 400 })
    }

    const material = await db.material.create({
      data: {
        name,
        unit
      }
    })

    return NextResponse.json(material, { status: 201 })
  } catch (error) {
    console.error('Error creating material:', error)
    return NextResponse.json({ error: 'Failed to create material' }, { status: 500 })
  }
}
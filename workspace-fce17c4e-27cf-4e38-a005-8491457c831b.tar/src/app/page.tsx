'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Search, Package, TrendingUp, TrendingDown, FileSpreadsheet, Download, Bell, CheckCircle, AlertCircle } from 'lucide-react'
import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'
import { io, Socket } from 'socket.io-client'

// WebSocket client
let socket: Socket | null = null

interface Material {
  id: string
  name: string
  partNumber?: string
  unit: string
  totalIn: number
  totalOut: number
  stock: number
}

interface MaterialInput {
  id: string
  date: string
  time: string
  quantity: number
  supplier: string
  notes: string
  material: {
    id: string
    name: string
    partNumber?: string
    unit: string
  }
}

interface MaterialOutput {
  id: string
  date: string
  time: string
  quantity: number
  unit: string
  destination: string
  recipient: string
  notes: string
  material: {
    id: string
    name: string
    partNumber?: string
    unit: string
  }
}

export default function Home() {
  const [activeTab, setActiveTab] = useState('input')
  const [materials, setMaterials] = useState<Material[]>([])
  const [inputs, setInputs] = useState<MaterialInput[]>([])
  const [outputs, setOutputs] = useState<MaterialOutput[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDate, setFilterDate] = useState('')
  
  // Real-time notification state
  const [notifications, setNotifications] = useState<Array<{
    id: string
    type: 'input' | 'output'
    message: string
    timestamp: string
    materialName: string
    quantity: number
    unit: string
  }>>([])

  // WebSocket connection
  useEffect(() => {
    // Initialize socket connection
    socket = io('http://localhost:3000', {
      transports: ['websocket', 'polling']
    })

    socket.on('connect', () => {
      console.log('Connected to real-time updates')
    })

    socket.on('material-update', (data) => {
      console.log('Received real-time update:', data)
      
      // Update local state based on update type
      if (data.type === 'material-input') {
        // Update inputs list
        setInputs(prev => {
          const newInput = data.data.input
          const existingIndex = prev.findIndex(item => item.id === newInput.id)
          
          if (existingIndex >= 0) {
            // Update existing input
            const updatedInputs = [...prev]
            updatedInputs[existingIndex] = newInput
            return updatedInputs
          } else {
            // Add new input
            return [newInput, ...prev]
          }
        })

        // Update materials list
        setMaterials(prev => {
          const updatedMaterial = data.data.material
          const existingIndex = prev.findIndex(item => item.id === updatedMaterial.id)
          
          if (existingIndex >= 0) {
            const updatedMaterials = [...prev]
            updatedMaterials[existingIndex] = updatedMaterial
            return updatedMaterials
          } else {
            return [updatedMaterial, ...prev]
          }
        })

        // Add notification
        addNotification({
          type: 'input',
          message: `${data.data.material.name} (${data.data.quantity} ${data.data.material.unit})`,
          timestamp: data.timestamp,
          materialName: data.data.material.name,
          quantity: data.data.input.quantity,
          unit: data.data.material.unit
        })
      } else if (data.type === 'material-output') {
        // Update outputs list
        setOutputs(prev => {
          const newOutput = data.data.output
          const existingIndex = prev.findIndex(item => item.id === newOutput.id)
          
          if (existingIndex >= 0) {
            // Update existing output
            const updatedOutputs = [...prev]
            updatedOutputs[existingIndex] = newOutput
            return updatedOutputs
          } else {
            // Add new output
            return [newOutput, ...prev]
          }
        })

        // Update materials list
        setMaterials(prev => {
          const updatedMaterial = data.data.material
          const existingIndex = prev.findIndex(item => item.id === updatedMaterial.id)
          
          if (existingIndex >= 0) {
            const updatedMaterials = [...prev]
            updatedMaterials[existingIndex] = updatedMaterial
            return updatedMaterials
          } else {
            return [updatedMaterial, ...prev]
          }
        })

        // Add notification
        addNotification({
          type: 'output',
          message: `${data.data.material.name} (${data.data.quantity} ${data.data.material.unit})`,
          timestamp: data.timestamp,
          materialName: data.data.material.name,
          quantity: data.data.output.quantity,
          unit: data.data.material.unit
        })
      }
    })

    socket.on('disconnect', () => {
      console.log('Disconnected from real-time updates')
    })

    return () => {
      if (socket) {
        socket.disconnect()
      }
    }
  }, [])

  // Notification helper function
  const addNotification = (notification: {
    type: 'input' | 'output'
    message: string
    timestamp: string
    materialName: string
    quantity: number
    unit: string
  }) => {
    const id = Date.now().toString()
    setNotifications(prev => [
      {
        id,
        ...notification,
        isNew: true
      },
      ...prev.slice(0, 4) // Keep only last 5 notifications
    ])

    // Remove 'isNew' flag after 3 seconds
    setTimeout(() => {
      setNotifications(prev => 
        prev.map(n => n.id === id ? { ...n, isNew: false } : n)
      )
    }, 3000)
  }

  // Form states for input
  const [inputForm, setInputForm] = useState({
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().split(' ')[0].substring(0, 5),
    materialName: '',
    partNumber: '',
    quantity: '',
    unit: 'zak',
    supplier: '',
    notes: ''
  })

  // Form states for output
  const [outputForm, setOutputForm] = useState({
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().split(' ')[0].substring(0, 5),
    materialName: '',
    partNumber: '',
    quantity: '',
    unit: 'zak',
    destination: '',
    recipient: '',
    notes: ''
  })

  // Load data from API
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load materials
        const materialsResponse = await fetch('/api/materials')
        if (materialsResponse.ok) {
          const materialsData = await materialsResponse.json()
          setMaterials(materialsData)
        }

        // Load inputs
        const inputsResponse = await fetch('/api/materials/input')
        if (inputsResponse.ok) {
          const inputsData = await inputsResponse.json()
          setInputs(inputsData)
        }

        // Load outputs
        const outputsResponse = await fetch('/api/materials/output')
        if (outputsResponse.ok) {
          const outputsData = await outputsResponse.json()
          setOutputs(outputsData)
        }
      } catch (error) {
        console.error('Error loading data:', error)
        // Fallback to mock data if API fails
        const mockMaterials: Material[] = [
          { id: '1', name: 'Semen', partNumber: 'SEM-001', unit: 'zak', totalIn: 100, totalOut: 30, stock: 70 },
          { id: '2', name: 'Pasir', partNumber: 'PAS-002', unit: 'm³', totalIn: 50, totalOut: 20, stock: 30 },
          { id: '3', name: 'Batu Split', partNumber: 'BAT-003', unit: 'm³', totalIn: 25, totalOut: 10, stock: 15 },
          { id: '4', name: 'Besi Beton', partNumber: 'BES-004', unit: 'kg', totalIn: 500, totalOut: 200, stock: 300 },
          { id: '5', name: 'Kawat Bendrat', partNumber: 'KWR-005', unit: 'roll', totalIn: 20, totalOut: 5, stock: 15 },
          { id: '6', name: 'Pipa PVC', partNumber: 'PVC-006', unit: 'meter', totalIn: 100, totalOut: 30, stock: 70 },
          { id: '7', name: 'Keramik', partNumber: 'KRM-007', unit: 'pack', totalIn: 50, totalOut: 15, stock: 35 },
          { id: '8', name: 'Alat Tulis', partNumber: 'ATL-008', unit: 'set', totalIn: 10, totalOut: 3, stock: 7 },
          { id: '9', name: 'Bata Merah', partNumber: 'BTM-009', unit: 'bh', totalIn: 1000, totalOut: 300, stock: 700 }
        ]
        setMaterials(mockMaterials)

        const mockInputs: MaterialInput[] = [
          { id: '1', date: '2024-01-15', time: '08:30', quantity: 50, supplier: 'Tiga Roda', notes: 'Pengiriman pertama', material: { id: '1', name: 'Semen', partNumber: 'SEM-001', unit: 'zak' } },
          { id: '2', date: '2024-01-16', time: '14:15', quantity: 25, supplier: 'Supplier lokal', notes: 'Kualitas bagus', material: { id: '2', name: 'Pasir', partNumber: 'PAS-002', unit: 'm³' } },
          { id: '3', date: '2024-01-17', time: '10:00', quantity: 10, supplier: 'Toko Bangunan Jaya', notes: 'Kawat bendrat', material: { id: '5', name: 'Kawat Bendrat', partNumber: 'KWR-005', unit: 'roll' } },
          { id: '4', date: '2024-01-18', time: '09:30', quantity: 50, supplier: 'Supplier PVC', notes: 'Pipa 4 inch', material: { id: '6', name: 'Pipa PVC', partNumber: 'PVC-006', unit: 'meter' } }
        ]
        setInputs(mockInputs)

        const mockOutputs: MaterialOutput[] = [
          { id: '1', date: '2024-01-17', time: '09:45', quantity: 15, unit: 'zak', destination: 'Pekerjaan pondasi', recipient: 'Budi Santoso', notes: 'Foundation rumah', material: { id: '1', name: 'Semen', partNumber: 'SEM-001', unit: 'zak' } },
          { id: '2', date: '2024-01-18', time: '16:20', quantity: 10, unit: 'm³', destination: 'Pekerjaan dinding', recipient: 'Ahmad Wijaya', notes: 'Campuran adukan', material: { id: '2', name: 'Pasir', partNumber: 'PAS-002', unit: 'm³' } },
          { id: '3', date: '2024-01-19', time: '11:30', quantity: 3, unit: 'roll', destination: 'Pekerjaan pagar', recipient: 'Siti Nurhaliza', notes: 'Kawat untuk pagar', material: { id: '5', name: 'Kawat Bendrat', partNumber: 'KWR-005', unit: 'roll' } },
          { id: '4', date: '2024-01-20', time: '13:15', quantity: 20, unit: 'meter', destination: 'Instalasi air', recipient: 'Rudi Hartono', notes: 'Pipa untuk saluran air', material: { id: '6', name: 'Pipa PVC', partNumber: 'PVC-006', unit: 'meter' } },
          { id: '5', date: '2024-01-21', time: '08:00', quantity: 5, unit: 'pack', destination: 'Pekerjaan lantai', recipient: 'Diana Putri', notes: 'Keramik ruang tamu', material: { id: '7', name: 'Keramik', partNumber: 'KRM-007', unit: 'pack' } },
          { id: '6', date: '2024-01-22', time: '10:30', quantity: 2, unit: 'set', destination: 'Kantor proyek', recipient: 'Eko Prasetyo', notes: 'Alat tulis kantor', material: { id: '8', name: 'Alat Tulis', partNumber: 'ATL-008', unit: 'set' } },
          { id: '7', date: '2024-01-23', time: '14:45', quantity: 100, unit: 'bh', destination: 'Pekerjaan dinding', recipient: 'Fajar Kurniawan', notes: 'Bata untuk dinding', material: { id: '9', name: 'Bata Merah', partNumber: 'BTM-009', unit: 'bh' } }
        ]
        setOutputs(mockOutputs)
      }
    }

    loadData()
  }, [])

  const handleInputSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inputForm.materialName || !inputForm.quantity) return

    try {
      const response = await fetch('/api/materials/input', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...inputForm,
          quantity: parseFloat(inputForm.quantity)
        })
      })

      if (response.ok) {
        const result = await response.json()
        
        // Update local state
        const newInput: MaterialInput = {
          id: result.input.id,
          date: inputForm.date,
          time: inputForm.time,
          quantity: parseFloat(inputForm.quantity),
          supplier: inputForm.supplier,
          notes: inputForm.notes,
          material: {
            id: result.material.id,
            name: inputForm.materialName,
            partNumber: inputForm.partNumber,
            unit: inputForm.unit
          }
        }

        setInputs(prev => [newInput, ...prev])
        
        // Update or add material in local state
        setMaterials(prev => {
          const existing = prev.find(m => m.name === inputForm.materialName)
          if (existing) {
            return prev.map(m => 
              m.name === inputForm.materialName 
                ? { ...m, totalIn: m.totalIn + newInput.quantity, stock: m.stock + newInput.quantity }
                : m
            )
          } else {
            return [...prev, {
              id: result.material.id,
              name: inputForm.materialName,
              unit: inputForm.unit,
              totalIn: newInput.quantity,
              totalOut: 0,
              stock: newInput.quantity
            }]
          }
        })

        // Reset form
        setInputForm({
          date: new Date().toISOString().split('T')[0],
          time: new Date().toTimeString().split(' ')[0].substring(0, 5),
          materialName: '',
          partNumber: '',
          quantity: '',
          unit: 'zak',
          supplier: '',
          notes: ''
        })
      } else {
        const error = await response.json()
        alert(error.error || 'Gagal menyimpan input material')
      }
    } catch (error) {
      console.error('Error submitting input:', error)
      alert('Terjadi kesalahan saat menyimpan data')
    }
  }

  const handleOutputSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!outputForm.materialName || !outputForm.quantity) return

    try {
      const response = await fetch('/api/materials/output', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...outputForm,
          quantity: parseFloat(outputForm.quantity)
        })
      })

      if (response.ok) {
        const result = await response.json()
        
        // Update local state
        const newOutput: MaterialOutput = {
          id: result.output.id,
          date: outputForm.date,
          time: outputForm.time,
          quantity: parseFloat(outputForm.quantity),
          unit: outputForm.unit,
          destination: outputForm.destination,
          recipient: outputForm.recipient,
          notes: outputForm.notes,
          material: {
            id: result.material.id,
            name: outputForm.materialName,
            partNumber: outputForm.partNumber,
            unit: outputForm.unit
          }
        }

        setOutputs(prev => [newOutput, ...prev])
        
        // Update material in local state
        setMaterials(prev => prev.map(m => 
          m.name === outputForm.materialName 
            ? { ...m, totalOut: m.totalOut + newOutput.quantity, stock: m.stock - newOutput.quantity }
            : m
        ))

        // Reset form
        setOutputForm({
          date: new Date().toISOString().split('T')[0],
          time: new Date().toTimeString().split(' ')[0].substring(0, 5),
          materialName: '',
          partNumber: '',
          quantity: '',
          unit: 'zak',
          destination: '',
          recipient: '',
          notes: ''
        })
      } else {
        const error = await response.json()
        alert(error.error || 'Gagal menyimpan output material')
      }
    } catch (error) {
      console.error('Error submitting output:', error)
      alert('Terjadi kesalahan saat menyimpan data')
    }
  }

  const filteredMaterials = materials.filter(material => 
    material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (material.partNumber && material.partNumber.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  const filteredInputs = inputs.filter(input => 
    (!filterDate || input.date === filterDate) &&
    (input.material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
     (input.material.partNumber && input.material.partNumber.toLowerCase().includes(searchTerm.toLowerCase())))
  )

  const filteredOutputs = outputs.filter(output => 
    (!filterDate || output.date === filterDate) &&
    (output.material.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
     (output.material.partNumber && output.material.partNumber.toLowerCase().includes(searchTerm.toLowerCase())))
  )

  const totalValue = materials.reduce((sum, m) => sum + m.stock, 0)

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredMaterials.map(material => ({
        'Nama Material': material.name,
        'Part Number': material.partNumber || '-',
        'Satuan': material.unit,
        'Total Masuk': material.totalIn,
        'Total Keluar': material.totalOut,
        'Stok Akhir': material.stock,
        'Status': material.stock > 10 ? 'Aman' : 'Rendah'
      }))
    )

    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Laporan Material')

    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' })
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
    
    const fileName = `Laporan_Material_${new Date().toISOString().split('T')[0]}.xlsx`
    saveAs(data, fileName)
  }

  // Sort materials by stock (low stock first)
  const sortedMaterials = [...materials].sort((a, b) => a.stock - b.stock)

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <Package className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">MaterialLog</h1>
              <p className="text-gray-600">Sistem Pencatatan Material Proyek - Akses Terbuka</p>
            </div>
          </div>
          
          {/* Real-time Notifications */}
          {notifications.length > 0 && (
            <div className="mb-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Bell className="h-5 w-5 text-blue-600 animate-pulse" />
                  <h3 className="font-semibold text-blue-900">Update Real-time</h3>
                </div>
                <div className="space-y-2">
                  {notifications.map((notification) => (
                    <div 
                      key={notification.id} 
                      className={`flex items-center gap-3 p-2 rounded-lg ${
                        notification.isNew ? 'bg-blue-100 border-blue-300' : 'bg-white border-gray-200'
                      } transition-all duration-300`}
                    >
                      <div className={`p-2 rounded-full ${
                        notification.type === 'input' ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {notification.type === 'input' ? (
                          <TrendingUp className="h-4 w-4 text-green-600" />
                        ) : (
                          <TrendingDown className="h-4 w-4 text-red-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">
                          {notification.message}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(notification.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {/* Welcome Message */}
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-600 rounded-full">
                <Package className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-green-900">Selamat Datang!</h3>
                <p className="text-sm text-green-700">
                  Sistem ini terbuka untuk umum. Siapa saja dapat langsung melakukan input dan output data material proyek.
                </p>
              </div>
            </div>
          </div>
          
          {/* Stock Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {sortedMaterials.map((material) => (
              <Card key={material.id} className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 text-sm mb-1">
                      {material.name}
                    </h3>
                    {material.partNumber && (
                      <p className="text-xs text-gray-500 font-mono mb-2">
                        {material.partNumber}
                      </p>
                    )}
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-gray-600">Stok</p>
                        <p className={`text-lg font-bold ${
                          material.stock > 10 ? 'text-green-600' : 
                          material.stock > 0 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {material.stock}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-600">Satuan</p>
                        <p className="text-sm font-medium text-gray-900">
                          {material.unit}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 pt-2 border-t border-gray-100">
                      <div className="flex justify-between text-xs">
                        <span className="text-green-600">+{material.totalIn}</span>
                        <span className="text-red-600">-{material.totalOut}</span>
                      </div>
                    </div>
                  </div>
                  <div className="ml-3">
                    <Badge 
                      variant={material.stock > 10 ? "default" : material.stock > 0 ? "secondary" : "destructive"}
                      className="text-xs"
                    >
                      {material.stock > 10 ? "Aman" : material.stock > 0 ? "Rendah" : "Habis"}
                    </Badge>
                  </div>
                </div>
              </Card>
            ))}
            
            {/* Summary Card */}
            <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
              <div className="flex items-center gap-2 mb-3">
                <Package className="h-5 w-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900">Ringkasan</h3>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total Material:</span>
                  <span className="text-sm font-bold">{materials.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total Stok:</span>
                  <span className="text-sm font-bold">{totalValue}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Stok Aman:</span>
                  <span className="text-sm font-bold text-green-600">
                    {sortedMaterials.filter(m => m.stock > 10).length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Stok Rendah:</span>
                  <span className="text-sm font-bold text-yellow-600">
                    {sortedMaterials.filter(m => m.stock > 0 && m.stock <= 10).length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Stok Habis:</span>
                  <span className="text-sm font-bold text-red-600">
                    {sortedMaterials.filter(m => m.stock === 0).length}
                  </span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="input">Input Material</TabsTrigger>
            <TabsTrigger value="output">Output Material</TabsTrigger>
            <TabsTrigger value="report">Laporan</TabsTrigger>
            <TabsTrigger value="history">Riwayat</TabsTrigger>
          </TabsList>

          {/* Input Material Tab */}
          <TabsContent value="input">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Input Material
                </CardTitle>
                <CardDescription>
                  Catat pemasukan material baru ke proyek
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleInputSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="input-date">Tanggal</Label>
                    <Input
                      id="input-date"
                      type="date"
                      value={inputForm.date}
                      onChange={(e) => setInputForm({...inputForm, date: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="input-time">Jam</Label>
                    <Input
                      id="input-time"
                      type="time"
                      value={inputForm.time}
                      onChange={(e) => setInputForm({...inputForm, time: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="input-material">Nama Material</Label>
                    <Input
                      id="input-material"
                      placeholder="Contoh: Semen, Pasir, Batu"
                      value={inputForm.materialName}
                      onChange={(e) => setInputForm({...inputForm, materialName: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="input-part-number">Part Number</Label>
                    <Input
                      id="input-part-number"
                      placeholder="Contoh: SEM-001, PAS-002"
                      value={inputForm.partNumber}
                      onChange={(e) => setInputForm({...inputForm, partNumber: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="input-quantity">Jumlah</Label>
                    <Input
                      id="input-quantity"
                      type="number"
                      step="0.01"
                      placeholder="0"
                      value={inputForm.quantity}
                      onChange={(e) => setInputForm({...inputForm, quantity: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="input-unit">Satuan</Label>
                    <Select value={inputForm.unit} onValueChange={(value) => setInputForm({...inputForm, unit: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="zak">Zak</SelectItem>
                        <SelectItem value="m³">m³</SelectItem>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="ton">Ton</SelectItem>
                        <SelectItem value="liter">Liter</SelectItem>
                        <SelectItem value="pcs">Pcs</SelectItem>
                        <SelectItem value="roll">Roll</SelectItem>
                        <SelectItem value="meter">Meter</SelectItem>
                        <SelectItem value="pack">Pack</SelectItem>
                        <SelectItem value="set">Set</SelectItem>
                        <SelectItem value="bh">Buah</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="input-supplier">Supplier / Sumber</Label>
                    <Input
                      id="input-supplier"
                      placeholder="Nama supplier"
                      value={inputForm.supplier}
                      onChange={(e) => setInputForm({...inputForm, supplier: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="input-notes">Keterangan</Label>
                    <Textarea
                      id="input-notes"
                      placeholder="Keterangan tambahan (opsional)"
                      value={inputForm.notes}
                      onChange={(e) => setInputForm({...inputForm, notes: e.target.value})}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Button type="submit" className="w-full">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      Simpan Input
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Output Material Tab */}
          <TabsContent value="output">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  Output Material
                </CardTitle>
                <CardDescription>
                  Catat pengeluaran material untuk pekerjaan
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleOutputSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="output-date">Tanggal</Label>
                    <Input
                      id="output-date"
                      type="date"
                      value={outputForm.date}
                      onChange={(e) => setOutputForm({...outputForm, date: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="output-time">Jam</Label>
                    <Input
                      id="output-time"
                      type="time"
                      value={outputForm.time}
                      onChange={(e) => setOutputForm({...outputForm, time: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="output-material">Nama Material</Label>
                    <Select value={outputForm.materialName} onValueChange={(value) => {
                      const selectedMaterial = materials.find(m => m.name === value)
                      setOutputForm({
                        ...outputForm, 
                        materialName: value,
                        partNumber: selectedMaterial?.partNumber || '',
                        unit: selectedMaterial?.unit || 'zak'
                      })
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih material" />
                      </SelectTrigger>
                      <SelectContent>
                        {materials.map((material) => (
                          <SelectItem key={material.id} value={material.name}>
                            {material.name} {material.partNumber && `(${material.partNumber})`} - Stok: {material.stock} {material.unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="output-part-number">Part Number</Label>
                    <Input
                      id="output-part-number"
                      placeholder="Part Number otomatis terisi"
                      value={outputForm.partNumber}
                      readOnly
                      className="bg-gray-50"
                    />
                  </div>
                  <div>
                    <Label htmlFor="output-quantity">Jumlah</Label>
                    <Input
                      id="output-quantity"
                      type="number"
                      step="0.01"
                      placeholder="0"
                      value={outputForm.quantity}
                      onChange={(e) => setOutputForm({...outputForm, quantity: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="output-unit">Satuan Barang</Label>
                    <Select value={outputForm.unit} onValueChange={(value) => setOutputForm({...outputForm, unit: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="zak">Zak</SelectItem>
                        <SelectItem value="m³">m³</SelectItem>
                        <SelectItem value="kg">kg</SelectItem>
                        <SelectItem value="ton">Ton</SelectItem>
                        <SelectItem value="liter">Liter</SelectItem>
                        <SelectItem value="pcs">Pcs</SelectItem>
                        <SelectItem value="roll">Roll</SelectItem>
                        <SelectItem value="meter">Meter</SelectItem>
                        <SelectItem value="pack">Pack</SelectItem>
                        <SelectItem value="set">Set</SelectItem>
                        <SelectItem value="bh">Buah</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="output-destination">Tujuan Pemakaian</Label>
                    <Input
                      id="output-destination"
                      placeholder="Contoh: Pekerjaan pondasi, dinding, atap"
                      value={outputForm.destination}
                      onChange={(e) => setOutputForm({...outputForm, destination: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="output-recipient">Nama Penerima</Label>
                    <Input
                      id="output-recipient"
                      placeholder="Nama penerima barang"
                      value={outputForm.recipient}
                      onChange={(e) => setOutputForm({...outputForm, recipient: e.target.value})}
                      required
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label htmlFor="output-notes">Keterangan</Label>
                    <Textarea
                      id="output-notes"
                      placeholder="Keterangan tambahan (opsional)"
                      value={outputForm.notes}
                      onChange={(e) => setOutputForm({...outputForm, notes: e.target.value})}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Button type="submit" className="w-full">
                      <TrendingDown className="h-4 w-4 mr-2" />
                      Simpan Output
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Report Tab */}
          <TabsContent value="report">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="h-5 w-5" />
                    Laporan Material
                  </span>
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    <Download className="h-4 w-4 mr-2" />
                    Export Excel
                  </Button>
                </CardTitle>
                <CardDescription>
                  Rekapitulasi semua material dan stok tersedia
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 mb-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Cari material..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="max-w-sm"
                    />
                  </div>
                </div>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nama Material</TableHead>
                        <TableHead>Part Number</TableHead>
                        <TableHead>Satuan</TableHead>
                        <TableHead className="text-right">Total Masuk</TableHead>
                        <TableHead className="text-right">Total Keluar</TableHead>
                        <TableHead className="text-right">Stok Akhir</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredMaterials.map((material) => (
                        <TableRow key={material.id}>
                          <TableCell className="font-medium">{material.name}</TableCell>
                          <TableCell className="font-mono text-sm">{material.partNumber || '-'}</TableCell>
                          <TableCell>{material.unit}</TableCell>
                          <TableCell className="text-right text-green-600">
                            +{material.totalIn}
                          </TableCell>
                          <TableCell className="text-right text-red-600">
                            -{material.totalOut}
                          </TableCell>
                          <TableCell className="text-right font-bold">
                            {material.stock}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant={material.stock > 10 ? "default" : "destructive"}>
                              {material.stock > 10 ? "Aman" : "Rendah"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <div className="space-y-6">
              {/* Input History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                    Riwayat Input Material
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-4">
                    <Input
                      type="date"
                      value={filterDate}
                      onChange={(e) => setFilterDate(e.target.value)}
                      className="max-w-xs"
                    />
                    <Input
                      placeholder="Cari material..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="max-w-sm"
                    />
                  </div>
                  <div className="rounded-md border max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tanggal</TableHead>
                          <TableHead>Jam</TableHead>
                          <TableHead>Material</TableHead>
                          <TableHead>Part Number</TableHead>
                          <TableHead className="text-right">Jumlah</TableHead>
                          <TableHead>Supplier</TableHead>
                          <TableHead>Keterangan</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredInputs.map((input) => (
                          <TableRow key={input.id}>
                            <TableCell>{input.date}</TableCell>
                            <TableCell className="font-mono text-sm">{input.time}</TableCell>
                            <TableCell>{input.material.name}</TableCell>
                            <TableCell className="font-mono text-sm">{input.material.partNumber || '-'}</TableCell>
                            <TableCell className="text-right text-green-600">
                              +{input.quantity} {input.material.unit}
                            </TableCell>
                            <TableCell>{input.supplier}</TableCell>
                            <TableCell className="text-sm text-gray-600">
                              {input.notes || '-'}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Output History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingDown className="h-5 w-5 text-red-600" />
                    Riwayat Output Material
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Tanggal</TableHead>
                          <TableHead>Jam</TableHead>
                          <TableHead>Material</TableHead>
                          <TableHead>Part Number</TableHead>
                          <TableHead className="text-right">Jumlah</TableHead>
                          <TableHead>Satuan</TableHead>
                          <TableHead>Tujuan</TableHead>
                          <TableHead>Penerima</TableHead>
                          <TableHead>Keterangan</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredOutputs.map((output) => (
                          <TableRow key={output.id}>
                            <TableCell>{output.date}</TableCell>
                            <TableCell className="font-mono text-sm">{output.time}</TableCell>
                            <TableCell>{output.material.name}</TableCell>
                            <TableCell className="font-mono text-sm">{output.material.partNumber || '-'}</TableCell>
                            <TableCell className="text-right text-red-600">
                              -{output.quantity}
                            </TableCell>
                            <TableCell>{output.unit}</TableCell>
                            <TableCell>{output.destination}</TableCell>
                            <TableCell>{output.recipient}</TableCell>
                            <TableCell className="text-sm text-gray-600">
                              {output.notes || '-'}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
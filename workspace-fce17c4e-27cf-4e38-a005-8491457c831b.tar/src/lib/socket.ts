import { Server } from 'socket.io';

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle material input updates
    socket.on('material-input', (data) => {
      console.log('Material input received:', data);
      // Broadcast to all connected clients
      io.emit('material-input-update', data);
    });

    // Handle material output updates
    socket.on('material-output', (data) => {
      console.log('Material output received:', data);
      // Broadcast to all connected clients
      io.emit('material-output-update', data);
    });

    // Handle material stock updates
    socket.on('material-stock-update', (data) => {
      console.log('Material stock update received:', data);
      // Broadcast to all connected clients
      io.emit('material-stock-update', data);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });

    // Send initial connection message
    socket.emit('connected', {
      message: 'Connected to MaterialLog real-time updates',
      timestamp: new Date().toISOString(),
    });
  });
};
# MaterialLog - Sistem Pencatatan Material Proyek

## 🎯 Tentang

MaterialLog adalah aplikasi web sederhana untuk mencatat pemasukan (input) dan pengeluaran (output) material proyek secara efisien dan mudah digunakan.

## 🌟 Fitur Utama

### 📥 Input Material
- Form input dengan kolom: Tanggal, Jam, Nama Material, Part Number, Jumlah, Satuan, Supplier, Keterangan
- Validasi otomatis untuk required fields
- Auto-create material jika belum ada
- Update stok otomatis saat input

### 📤 Output Material
- Form output dengan kolom: Tanggal, Jam, Nama Material, Jumlah, Satuan Barang, Tujuan, Nama Penerima, Keterangan
- Validasi stok - tidak bisa mengeluarkan material lebih dari stok tersedia
- Dropdown material menampilkan stok tersedia
- Update stok otomatis saat output

### 📊 Dashboard & Laporan
- Dashboard dengan stok per material (real-time)
- Status indikator (Aman/Rendah/Habis)
- Tabel rekap material dengan Part Number
- Pencarian dan filter berdasarkan tanggal dan nama material
- Export ke Excel dengan data lengkap

### 📋 Riwayat Transaksi
- Riwayat Input Material dengan filter tanggal dan pencarian
- Riwayat Output Material dengan informasi penerima
- Tabel scrollable untuk data yang banyak
- Informasi lengkap dengan jam dan tanggal

## 🚀 Cara Penggunaan

### 1. Akses Sistem
- Buka browser dan kunjungi URL aplikasi
- **Tidak perlu login** - sistem terbuka untuk umum
- Langsung dapat melakukan input dan output data

### 2. Input Material
1. Buka tab "Input Material"
2. Isi form dengan data material yang masuk
3. Klik "Simpan Input"

### 3. Output Material
1. Buka tab "Output Material"
2. Pilih material dari dropdown (hanya material dengan stok > 0)
3. Isi data pengeluaran
4. Klik "Simpan Output"

### 4. Lihat Laporan
1. Buka tab "Laporan" untuk melihat rekap stok
2. Buka tab "Riwayat" untuk melihat transaksi
3. Gunakan filter dan pencarian untuk data spesifik
4. Export ke Excel jika diperlukan

## 📋 Satuan yang Tersedia

- **Zak** - untuk semen, gandum, dll
- **m³** - untuk pasir, batu, tanah, dll
- **kg** - untuk besi, bahan kimia, dll
- **Ton** - untuk material berat
- **Liter** - untuk cairan, cat, dll
- **Pcs** - untuk item individual
- **Roll** - untuk kawat, kabel, kertas, dll
- **Meter** - untuk pipa, kabel, bahan panjang, dll
- **Pack** - untuk keramik, genteng, dll
- **Set** - untuk alat-alat dalam satu set
- **Buah** - untuk item individual (bata, batu bata, dll)

## 🛠️ Teknologi

- **Framework**: Next.js 15 dengan App Router
- **Database**: SQLite dengan Prisma ORM
- **UI**: Tailwind CSS dengan shadcn/ui components
- **Language**: TypeScript
- **Export**: XLSX untuk export Excel

## 📱 Cara Menjalankan

```bash
# Install dependencies
npm install

# Push database schema
npm run db:push

# Generate Prisma client
npm run db:generate

# Jalankan development server
npm run dev
```

Aplikasi akan berjalan di `http://localhost:3000`

## 🎨 Fitur Tambahan

- **Responsive Design**: Optimal di mobile dan desktop
- **Real-time Updates**: Stok terupdate otomatis
- **Data Validation**: Validasi input dan stok
- **Export Function**: Download laporan ke Excel
- **Search & Filter**: Pencarian material yang mudah
- **Status Indicators**: Visual warning untuk stok rendah

## 📞 Bantuan

Jika mengalami masalah:
1. Pastikan semua dependencies terinstall
2. Cek database connection
3. Refresh browser jika perlu
4. Pastikan server development berjalan

---

*Sistem ini dirancang untuk kemudahan penggunaan dan akses terbuka bagi tim proyek*